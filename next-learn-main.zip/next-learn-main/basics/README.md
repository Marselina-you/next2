# next-learn-starter

This repository contains starter templates for [Learn Next.js](https://nextjs.org/learn).

The final result for the basics lesson can be found in the [demo](demo) directory and is available at: [https://next-learn-starter.vercel.app/](https://next-learn-starter.vercel.app/).
